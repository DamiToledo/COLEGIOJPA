package ar.org.centro8.especialidad.web.interfaces;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColegioApplicationTests {

	@Test
	void contextLoads() {
	}

}
